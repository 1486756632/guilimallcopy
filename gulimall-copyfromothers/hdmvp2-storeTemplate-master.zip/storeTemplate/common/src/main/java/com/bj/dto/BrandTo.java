package com.bj.dto;

import lombok.Data;

@Data
public class BrandTo {

    /**
     * "brandId": 0,
     * "brandName": "string",
     */
    private Long brandId;

    private String  brandName;
}
