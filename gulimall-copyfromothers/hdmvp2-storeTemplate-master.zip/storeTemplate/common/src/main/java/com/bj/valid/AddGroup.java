package com.bj.valid;

public interface AddGroup {
}
