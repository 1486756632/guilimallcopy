package com.bj.constant;

/**
 * <p>Title: CartConstant</p>
 * Description：
 * date：2020/6/27 22:37
 */
public class CartConstant {

	public static final String TEMP_USER_COOKIE_NAME = "user-key";

	public static final int TEMP_USER_COOKIE_TIME_OUT = 60 * 60 * 24 * 30;
}
