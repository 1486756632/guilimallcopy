# storeTemplate

#### 介绍
这是一个通用商城类项目模板

#### 软件架构
软件架构说明
  该系统采用分布式架构，jdk版本选用1.8
  数据库使用percona数据库5.7版本
  Redis版本5.0.2，集群搭建
  rabbitMq版本3.8
  nacos作为微服务注册中心
  前端管理端使用vue，用户端使用themleaf
#### 安装教程

1.  xxxx
2.  xxxx
3.  xxxx

#### 使用说明

1.  项目集成了较多第三方工具一定要注意，版本问题
2.  xxxx
3.  xxxx

#### 参与贡献

1.  init 本仓库
2.  新建 develop_xxx 分支
3.  提交代码
4.  新建 Pull Request


#### 码云特技

1.  使用 Readme\_XXX.md 来支持不同的语言，例如 Readme\_en.md, Readme\_zh.md
2.  码云官方博客 [blog.gitee.com](https://blog.gitee.com)
3.  你可以 [https://gitee.com/explore](https://gitee.com/explore) 这个地址来了解码云上的优秀开源项目
4.  [GVP](https://gitee.com/gvp) 全称是码云最有价值开源项目，是码云综合评定出的优秀开源项目
5.  码云官方提供的使用手册 [https://gitee.com/help](https://gitee.com/help)
6.  码云封面人物是一档用来展示码云会员风采的栏目 [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)
