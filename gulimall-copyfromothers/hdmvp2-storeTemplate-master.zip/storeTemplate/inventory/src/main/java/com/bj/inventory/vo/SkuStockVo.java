package com.bj.inventory.vo;

import lombok.Data;

/**
 * @ClassName SkuStockVo
 * @Description TODO
 * @Author 13011
 * @Date 2020/11/3 16:29
 * @Version 1.0
 **/
@Data
public class SkuStockVo {
private Long skuId;
private Boolean hasStock;
}
