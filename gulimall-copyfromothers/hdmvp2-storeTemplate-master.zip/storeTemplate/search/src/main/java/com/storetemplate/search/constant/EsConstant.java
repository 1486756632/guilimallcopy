package com.storetemplate.search.constant;

/**
 * @ClassName EsConstant
 * @Description TODO
 * @Author 13011
 * @Date 2020/11/4 19:25
 * @Version 1.0
 **/
public class EsConstant {
    public static final String PRODUCT_INDEX="product";

}
