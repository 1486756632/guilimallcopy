package com.storetemplate.auth;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthApplicationTests {

    @Test
    void contextLoads() {
    }

}
