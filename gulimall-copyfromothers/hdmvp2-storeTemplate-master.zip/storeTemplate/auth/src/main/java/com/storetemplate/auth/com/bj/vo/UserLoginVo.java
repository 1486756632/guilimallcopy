package com.storetemplate.auth.com.bj.vo;

import lombok.Data;

/**
 * <p>Title: UserLoginVo</p>
 * Description：
 * date：2020/6/25 21:38
 */
@Data
public class UserLoginVo {

	private String loginacct;

	private String password;
}
