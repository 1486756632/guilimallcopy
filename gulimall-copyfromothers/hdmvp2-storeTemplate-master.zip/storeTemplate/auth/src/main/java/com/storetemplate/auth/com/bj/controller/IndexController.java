package com.storetemplate.auth.com.bj.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @ClassName IndexController
 * @Description TODO
 * @Author 13011
 * @Date 2020/12/27 15:29
 * @Version 1.0
 **/
@Controller
public class IndexController {
//    @GetMapping("/index.html")
//    public String index(){
//        return "index";
//    }
//    @GetMapping("/reg.html")
//    public String reg(){
//        return "reg";
//    }

}
