package com.bj.order.constant;

/**
 * <p>Title: OrderConstant</p>
 * Description：
 * date：2020/7/1 22:13
 */
public class OrderConstant {

	public static final String USER_ORDER_TOKEN_PREFIX = "order:token";
}
