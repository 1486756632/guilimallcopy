package com.bj.order.vo;

import lombok.Data;

/**
 * <p>Title: SkuStockVo</p>
 * Description：
 * date：2020/7/1 12:03
 */
@Data
public class SkuStockVo {
	private Long skuId;

	private Boolean hasStock;
}
