package com.bj.order.config;

/**
 * <p>Title: MySeataConfig</p>
 * Description：
 * date：2020/7/3 14:04
 */
//@Configuration
public class MySeataConfig {

//	@Bean
//	public DataSource dataSource(DataSourceProperties dataSourceProperties){
//		HikariDataSource dataSource = dataSourceProperties.initializeDataSourceBuilder().type(HikariDataSource.class).build();
//		if(StringUtils.hasText(dataSourceProperties.getName())){
//			dataSource.setPoolName(dataSourceProperties.getName());
//		}
//		return new DataSourceProxy(dataSource);
//	}
}
