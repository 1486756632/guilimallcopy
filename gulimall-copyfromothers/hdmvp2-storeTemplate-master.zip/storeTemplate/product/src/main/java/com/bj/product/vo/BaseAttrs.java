package com.bj.product.vo;

import lombok.Data;

/**
 * Auto-generated: 2020-09-20 17:41:13
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
@Data
public class BaseAttrs {

    private Long attrId;
    private String attrValues;
    private Integer showDesc;

}