package com.bj.product.vo;

import lombok.Data;

import java.math.BigDecimal;

/**
 * Auto-generated: 2020-09-20 17:41:13
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
@Data
public class Bounds {

    private BigDecimal buyBounds;
    private BigDecimal growBounds;

}