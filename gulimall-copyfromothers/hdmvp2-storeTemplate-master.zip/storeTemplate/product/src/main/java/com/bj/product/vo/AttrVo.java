package com.bj.product.vo;

import com.bj.product.entity.AttrEntity;
import lombok.Data;

/**
 * @ClassName AttrVo
 * @Description TODO
 * @Author 13011
 * @Date 2020/9/6 14:30
 * @Version 1.0
 **/
@Data
public class AttrVo extends AttrEntity {
     private Long attrGroupId;
}
