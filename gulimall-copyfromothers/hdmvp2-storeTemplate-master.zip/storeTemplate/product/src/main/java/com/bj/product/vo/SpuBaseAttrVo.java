package com.bj.product.vo;

import lombok.Data;
import lombok.ToString;

@ToString
@Data
public class SpuBaseAttrVo{
	private String attrName;

	private String attrValue;
}