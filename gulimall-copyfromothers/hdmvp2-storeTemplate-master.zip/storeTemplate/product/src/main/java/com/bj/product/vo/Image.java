package com.bj.product.vo;

import lombok.Data;

/**
 * @ClassName Image
 * @Description TODO
 * @Author 13011
 * @Date 2020/9/20 23:28
 * @Version 1.0
 **/
@Data
public class Image {
    private String imgUrl;
    private Integer defaultImg;
}
