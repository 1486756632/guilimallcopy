package com.bj.product.vo;

import lombok.Data;

/**
 * <p>Title: AttrValueWithSkuIdVo</p>
 * Description：
 * date：2020/6/24 23:38
 */
@Data
public class AttrValueWithSkuIdVo {

	private String attrValue;

	private String skuIds;
}
