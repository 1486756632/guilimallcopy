package com.bj.cupon;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CuponApplicationTests {

    @Test
    void contextLoads() {
    }

}
